/* global $ */
/* global location $ */
/* global imports $ */
/*
function _(id){ return document.getElementById(id); }
function submitForm(){
	_("contact_send").disabled = true;
	_("status").innerHTML = 'please wait ...';
	var formdata = new FormData();
	formdata.append( "name", _("name").value );
	formdata.append( "email", _("email").value );
	formdata.append( "subject", _("subject").value );
	formdata.append( "message", _("message").value );
	var ajax = new XMLHttpRequest();
	ajax.open( "POST", "contact.php" );
	ajax.onreadystatechange = function() {
		if(ajax.readyState == 4 && ajax.status == 200) {
			if(ajax.responseText == "success"){
				_("contact_form").innerHTML = '<h2>Thanks '+_("name").value+', your message has been sent.</h2>';
			} else {
				_("status").innerHTML = ajax.responseText;
				_("contact_send").disabled = false;
			}
		}
	}
	ajax.send( formdata );
}

*/
	
$(document).ready(function(){  
      $('#coupone_submit').click(function(){  
           var coupone_code = $('#coupone_code').val();  
           if($.trim(coupone_code).length > 0)  
           {  
                $.ajax({  
                     url:"checkout_main.php",  
                     method:"POST",  
                     data:{coupone_code:coupone_code},  
                     async: false,
                     success: function(data)  
                     {  
                          if(data == 1)  
                          {
                               alert("success");
                          }  
                          else  
                          {  
                            	alert("invalid code");
                          }  
                     },
                     cache: false
                });
           }  
           else  
           {  
               alert("enter coupone code");
               return false;  
           }  
      });  
 });


//register
	$(document).ready(function(){
	
	var form = $("#registration_form");
	var username = $("#reg_username");
	var username_info = $("#username_error_message");
	var f_name = $("#reg_f_name");
	var f_name_info = $("#f_name_error_message");
	var l_name = $("#reg_l_name");
	var l_name_info = $("#l_name_error_message");
	var email = $("#reg_email");
	var email_info = $("#email_error_message");
	var pass = $("#reg_password");
	var pass_info = $("#password_error_message");
	var re_pass = $("#reg_re_password");
	var re_pass_info = $("#re_password_error_message");
	var state = false;

	
	username.keyup(validate_username);
	f_name.keyup(validate_f_name);
	l_name.keyup(validate_l_name);
	email.keyup(validate_email);
	pass.keyup(validate_pass);
	re_pass.keyup(validate_re_pass);
	
	function validate_username(){
		if(username.val().length <= 4){
			username.removeClass('valid');
			username_info.removeClass('valid');
			username.addClass('error');
			username_info.addClass('error');
			username_info.text("Username must be at least 5 characters");
			state = false;
		}else{
			if(username.val().length >4){
				var uusername = username.val();
				$.post('validate.php', {usernames : uusername}, function(data){
					if(data == 0){
						username.removeClass('valid');
						username_info.removeClass('valid');
						username.addClass('error');
						username_info.addClass('error');
						username_info.text("Username already exixst");
						state = false;
					}else{
						username.removeClass('error');
						username_info.removeClass('error');
						username.addClass('valid');
						username_info.addClass('valid');
						username_info.text("");
						state = true;
					}
				});				
			}
		}
		return state;
	}
	
	function validate_f_name(){
		if(f_name.val().length < 3){
			f_name.removeClass('valid');
			f_name_info.removeClass('valid');
			f_name.addClass('error');
			f_name_info.addClass('error');
			f_name_info.text("First name must be at least 3 characters");
			state = false;
		}else{
			f_name.removeClass('error');
			f_name_info.removeClass('error');
			f_name.addClass('valid');
			f_name_info.addClass('valid');
			f_name_info.text("");
			state = true;
		}
		return state;
	}
	
	function validate_l_name(){
		if(l_name.val().length < 3){
			l_name.removeClass('valid');
			l_name_info.removeClass('valid');
			l_name.addClass('error');
			l_name_info.addClass('error');
			l_name_info.text("Last name must be at least 3 characters");
			state = false;
		}else{
			l_name.removeClass('error');
			l_name_info.removeClass('error');
			l_name.addClass('valid');
			l_name_info.addClass('valid');
			l_name_info.text("");
			validate_re_pass();
			state = true;
		}
		return state;
	}
	
	function validate_email(){
		var a = email.val();
		var filter = /^[a-zA-Z0-9]+[a-zA-Z0-9_.-]+[a-zA-Z0-9_.-]+@[a-zA-Z0-9]+[a-zA-Z0-9.-]+[a-zA-Z0-9]+.[a-z]{2,4}$/;
		
		if(filter.test(a)){
			$.post('validate.php', {emails : a}, function(data){
				if(data == 0){
					email.removeClass('valid');
					email_info.removeClass('valid');
					email.addClass('error');
					email_info.addClass('error');
					email_info.text("Email already exixst");
					state = false;
				}else{
					email.removeClass('error');
					email_info.removeClass('error');
					email.addClass('valid');
					email_info.addClass('valid');
					email_info.text("");
					state = true;
				}
			});
		}else{
			email.removeClass('valid');
			email_info.removeClass('valid');
			email.addClass('error');
			email_info.addClass('error');
			email_info.text("Invalid email address");
			state = false;
		}
		return state;
	}
	
	function validate_pass(){
		if(pass.val().length < 5){
			pass.removeClass('valid');
			pass_info.removeClass('valid');
			pass.addClass('error');
			pass_info.addClass('error');
			pass_info.text("Password must be at least 5 characters");
			state = false;
		}else{
			pass.removeClass('error');
			pass_info.removeClass('error');
			pass.addClass('valid');
			pass_info.addClass('valid');
			pass_info.text("");
			validate_re_pass();
			state = true;
		}
		return state;
	}
	
	function validate_re_pass(){
		if(pass.val() != re_pass.val() || pass.val().length === 0){
			re_pass.removeClass('valid');
			re_pass_info.removeClass('valid');
			re_pass.addClass('error');
			re_pass_info.addClass('error');
			re_pass_info.text("Passwords not match");
			state = false;
		}else{
			re_pass.removeClass('error');
			re_pass_info.removeClass('error');
			re_pass.addClass('valid');
			re_pass_info.addClass('valid');
			re_pass_info.text("");
			state = true;
		}
		return state;
	}
	
	
	$(document).off('click', '#reg_submit').on('click', '#reg_submit', function(){
		var all = $("#registration_form").serialize();
		if((validate_username() & validate_f_name() & validate_l_name() & validate_email() & validate_pass() & validate_re_pass()) == true){
			$.ajax({
				type: "POST",
				url: "insert.php",
				data: all,
				success: function(data){
					if(data == 1){
						//alert("Registration successful");
						window.location.replace("login.php");
					}
				}
			});
			alert("Registration successful");
		}else{
			alert("Please fill all fields");
			return false;
		}
	});
	
});


//login

$(document).ready(function(){  
      $('#log_submit').click(function(){  
           var username = $('#log_username').val();  
           var password = $('#log_password').val();  
           if($.trim(username).length > 0 && $.trim(password).length > 0)  
           {  
                $.ajax({  
                     url:"login_check.php",  
                     method:"POST",  
                     data:{username:username, password:password},  
                     async: false,
                     success: function(data)  
                     {  
                          if(data == 1)  
                          {
                               
                               window.location.replace("index.php");
                               alert("success");
                             
                          }  
                          else  
                          {  
                               
                            	alert("invalid password or username");
                          }  
                     },
                     cache: false
                });
           }  
           else  
           {  
               alert("enter username");
               return false;  
           }  
      });  
 });







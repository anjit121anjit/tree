
<a href  = "new.php?type=women">Women</a>

<a href = "new.php?product=shirt?type=mens">Shirt</a>

